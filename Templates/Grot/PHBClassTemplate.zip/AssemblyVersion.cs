using System;
using System.Reflection;

[assembly: System.Reflection.AssemblyVersionAttribute("0.0.0.0")]
[assembly: System.Reflection.AssemblyFileVersionAttribute("0.0.0.0")]

